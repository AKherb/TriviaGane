//
//  ViewController.swift
//  Secutiyapp
//
//  Created by Aryan Kashyap on 5/13/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

