//
//  ViewController.swift
//  Global Trivia
//
//  Created by Aryan Kashyap on 12/18/22.
//

import UIKit
import Foundation
import SwiftUI
import Swift

class ViewController: UIViewController {

    var sampleString: String!;
    var score = 0;
    //var country : Country!;
    
    
    
    
    var Q : [[Question]] = [[Question]](repeating: [Question](repeating: Question(QQ: "Hello", ACs: ["h", "h", "h", "h"], correctAnswer: "hello", AnswerExplination: "hello", pointEnabled: true), count: 5), count: 5)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //print(southAfricaQuestions)
        // Do any additional setup after loading the view.
        
        
    }
    
    
    @IBAction func tanzaniaButton()
    {
        //sampleString = "tanzania"
    }
    
    @IBAction func southAfricaButton()
    {
        //sampleString = "South Africa"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.identifier == "southAfricaSegue"
        {
            
            sampleString = "South Africa"
            
            for m in 0..<Q.count{
               for n in 0..<Q[m].count{
                   Q[m][n].pointEnabled = true;
               }
            }
          
            Q[0][0].QQ = "South Africa is the _____ country of mainland Africa"
            Q[0][0].ACs = ["Northernmost", "Southernmost", "Easternmost", "Westarnmost"]
            Q[0][0].correctAnswer = "Southernmost"
            Q[0][0].AnswerExplination = "South Africa is located on the Southernmost tip of Africa. This allows the country to be a hub for ships sailing around the continent. Cape Town is connsidered the Southernmost city of Africa!"
            //Q[0][0].pointEnabled = true;
            
            Q[0][1].QQ = "Which is the most populous city in South Africa?"
            Q[0][1].ACs = ["Johannesburg", "Cape Town", "Durban", "Lagos"]
            Q[0][1].correctAnswer = "Johannesburg"
            Q[0][1].AnswerExplination = "Johannesburg is the most populous city in South Africa with a population of more than five million citizens. Johannesburg is also the economic capital of South Africa. In fact, the Johannesburg Stock Exchange is the largest exchange on the continent!"
            
            
            Q[0][2].QQ = "Which major desert runs through South Africa?"
            Q[0][2].ACs = ["Sahara Desert", "Gobi Desert", "Kalahari Desert", "Antarctica"]
            Q[0][2].correctAnswer = "Kalahari Desert"
            Q[0][2].AnswerExplination = "The Kalahari Desert covers 930,000 square kilometres of Southern Africa. It is home to diverse wildlife and some of the world's highest sand dunes. However, the Kalahari can be inhospitibal for humanns."
            
            Q[0][3].QQ = "South Africa is the leading producer of _______."
            Q[0][3].ACs = ["Gold", "Chrome", "Sillicon", "Copper"]
            Q[0][3].correctAnswer = "Chrome"
            Q[0][3].AnswerExplination = "South Africa produces nearly 40% of the world's Chromite. They mined 18 million tons of the metal in 2021 alone!"
            
            Q[0][4].QQ = "How many countries does South Africa border?"
            Q[0][4].ACs = ["9", "3", "5", "6"]
            Q[0][4].correctAnswer = "6"
            Q[0][4].AnswerExplination = "South Africa borders Namibia, Botswana, Zimbabwe, Mozambique, Eswatini and Lesotho. The kingdom of Lesotho is completly surrounded by South Africa."
            
            
            
            
            Q[1][0].QQ = "Who colonized South Africa?"
            Q[1][0].ACs = ["F*****", "Britan", "Holy Roman Empire", "Nigeria"]
            Q[1][0].correctAnswer = "Britan"
            Q[1][0].AnswerExplination = "The area of South Africa was colonized by both the Dutch and British. The first European colony was established in 1652, and the Dutch were kicked out by the British in 1795. South Africa left the Commonwelth in 1961."
            
            Q[1][1].QQ = "Who was Nelson Mandela"
            Q[1][1].ACs = ["A genocidal maniac", "Former South African President", "Obama's first and middle name", "A influencer"]
            Q[1][1].correctAnswer = "Former South African President"
            Q[1][1].AnswerExplination = "Nelson Mandela was the first democratacly elected president of South Africa. He devoted his life to fighting of equal rights. His election is widly belived to mark the end of Aparthid in the country. Mandela has been praised worldwide for his commitment to peace. He won the Nobel Peace Prize in 1993."
            
            Q[1][2].QQ = "What percent of the South African population is white?"
            Q[1][2].ACs = ["8%", "20%", "17%", "2%"]
            Q[1][2].correctAnswer = "8%"
            Q[1][2].AnswerExplination = "Around 8% of South Africa's polulation is white. However, the white minority was still able to opress the majority under Aparthid. The white population still owns a majority of the land in South Africa."
            
            Q[1][3].QQ = "Which religon is most commonly practiced in South Africa"
            Q[1][3].ACs = ["Christianity", "Hinduism", "Racism", "Islam"]
            Q[1][3].correctAnswer = "Christianity"
            Q[1][3].AnswerExplination = "Christianity is the most practiced religion in South Africa. 68% of South Africans are Christans!"
            
            Q[1][4].QQ = "What is the largest Ethnic group in South Africa?"
            Q[1][4].ACs = ["Zulu", "Sotho", "Tswana", "Xhosa"]
            Q[1][4].correctAnswer = "Zulu"
            Q[1][4].AnswerExplination = "22.9% of South Africans identifies as Zulu. 16.5% are Xhosa, and 17.4% are Sotho."
            
            
            
            
            Q[2][0].QQ = "Which of these places is considered the \"Great White Capital of the world\""
            Q[2][0].ACs = ["Cape Town", "Gansbaai", "Johannesburg", "Durban"]
            Q[2][0].correctAnswer = "Gansbaai"
            Q[2][0].AnswerExplination = "Gansbaai is the Great White Capital of the world. Great Whites visit year round, making Gansbaai a destination for thrill seakers and adreneline junkies. Cage diving in Gansbaai is very popular!"
            
            Q[2][1].QQ = "Which of these snakes can be found in South Africa"
            Q[2][1].ACs = ["Lowland copperhead", "Tiger snake", "Red bellied black snake", "Cape Cobra"]
            Q[2][1].correctAnswer = "Cape Cobra"
            Q[2][1].AnswerExplination = "The Cape Cobra, also known as the Yellow Cobra, is found thorought the Southern part of the continent. They can be found in nearly all South African provinces. They are highly venomus."
            
            Q[2][2].QQ = "Which is the national bird of South Africa?"
            Q[2][2].ACs = ["The Blue Crane", "The Bald Eagle", "The Cardinal", "The Flamingo"]
            Q[2][2].correctAnswer = "The Blue Crane"
            Q[2][2].AnswerExplination = "The Blue Crane is a relitivly small crane found almost exclusivly in South Africa. The bird is honored in many South African cultures."
            
            Q[2][3].QQ = "Which of these is the national animal of South Africa?"
            Q[2][3].ACs = ["The South African Lion", "The Springbok", "The Blue Crane", "The Cape Cobra"]
            Q[2][3].correctAnswer = "The Springbok"
            Q[2][3].AnswerExplination = "The Springbok is the national animal of South Africa. The Springbok is a small white and brown gazelle. It has two antlers which resemble horns."
            
            Q[2][4].QQ = "The nickname \"Jackass Penguin\", primarily found in South Africa refers to which penguin"
            Q[2][4].ACs = ["The Pittsburgh Penguins", "The Emporor Penguins", "The African Penguins", "The King Penguins"]
            Q[2][4].correctAnswer = "The African Penguins"
            Q[2][4].AnswerExplination = "African Penguins are primarly found near the coast of South Africa and Namibia. These medium sized penguins face extinction due to predation. They got their derogetory nickname due to the donkey-like sound they emmit."
            
            
            Q[3][0].QQ = "Who is the most famous South African?"
            Q[3][0].ACs = ["Drake", "Obama", "Nelson Mandela", "Biden"]
            Q[3][0].correctAnswer = "Nelson Mandela"
            Q[3][0].AnswerExplination = "Nelson Mandela was the first democratacly elected president of South Africa. He devoted his life to fighting of equal rights. His election is widly belived to mark the end of Aparthid in the country. Mandela has been praised worldwide for his commitment to peace. He won the Nobel Peace Prize in 1993."
            
            Q[3][1].QQ = "What is South Africa's national sport?"
            Q[3][1].ACs = ["American Football", "Rugby", "Cricket", "Soccer"]
            Q[3][1].correctAnswer = "Soccer"
            Q[3][1].AnswerExplination = "Soccor is South Africa's national sport. The national team has qualified thrice for the FIFA World Cup in 1998, 2002, and 2010. South Africa hosted the 2010 FIFA world cup. A large number of soccer clubs operate in the country."
            
            Q[3][2].QQ = "What Slang Word/Phrase means \"great or nice\" in South Africa?"
            Q[3][2].ACs = ["Howzit", "Lekker", "Yebo", "Bru"]
            Q[3][2].correctAnswer = "Lekker"
            Q[3][2].AnswerExplination = "Lekker is slang in South Africa for \"great of nice.\" You could say this project is Lekker and Mr. Babich's class is also very Lekker!"
            
            Q[3][3].QQ = "Which one of these cricketers plays for South Africa?"
            Q[3][3].ACs = ["Quinton de Kock", "Virat Kohli", "Steve Smith", "Babar Azam"]
            Q[3][3].correctAnswer = "Quinton de Kock"
            Q[3][3].AnswerExplination = "Quinton de Kock is the former captin of South Africa's cricket team. He is left handed and plays wicket keeper."
            
            Q[3][4].QQ = "How many offical languages does South Africa Have?"
            Q[3][4].ACs = ["15", "1", "9", "11"]
            Q[3][4].correctAnswer = "11"
            Q[3][4].AnswerExplination = "South Africa's constitution recognizes 11 offical languages. Sepedi, Sesotho, Setswana, siSwati, Tshivenda, Xitsonga, Afrikaans, English, isiNdebele, isiXhosa and isiZulu"
            
            
            
            Q[4][0].QQ = "South Africa is around ______ times the size of Texas."
            Q[4][0].ACs = ["1/2", "1/3", "3", "2"]
            Q[4][0].correctAnswer = "2"
            Q[4][0].AnswerExplination = "South Africa is around twice times the size of the State of Texas. Texas is around 695,662 km² but South Arfica is around 1,219,090 km²"
            
            Q[4][1].QQ = "What year did the first heart transplant take place?"
            Q[4][1].ACs = ["1967", "1993", "1979", "2001"]
            Q[4][1].correctAnswer = "1967"
            Q[4][1].AnswerExplination = "The first heart transplant took place on December 3, 1967 in Cape Town, South Africa. The patient who recived the transplant unfortunetly died 18 days later."
            
            Q[4][2].QQ = "Which landlocked kingdom is compleatly surrounded by South Africa?"
            Q[4][2].ACs = ["Kosovo", "Liechtenstein", "Eswatini", "Lesotho"]
            Q[4][2].correctAnswer = "Lesotho"
            Q[4][2].AnswerExplination = "Lesotho encompases a mountanis 30,360 km² patch enclosed by South Africa. With a population of around 2 million, Lesotho is a fully sovereign state recognized by the Unithed Nations."
            
            Q[4][3].QQ = "Which UNESCO World Herritige Site holds the nickname \"Cradle of Humankind\""
            Q[4][3].ACs = ["Sterkfontein", "Vredefort", "Mpumalanga", "Table Bay"]
            Q[4][3].correctAnswer = "Sterkfontein"
            Q[4][3].AnswerExplination = "Sterkfontein is a set of caves near Johannesburg. Here, many fossils from early human ansestors are found. There have been nearly 500 hominids found, making The Cradle of Humankind evidence that humans originated in Africa."
        
            Q[4][4].QQ = "Who is the current President of South Africa?"
            Q[4][4].ACs = ["Nelson Mandela", "Jacob Zuma", "Cyril Ramaphosa", "Obama"]
            Q[4][4].correctAnswer = "Cyril Ramaphosa"
            Q[4][4].AnswerExplination = "Cyril Ramaphosa is the fifth democraticly elected president of South Africa. He is an anti-apartheid activist and was formerly the chairman of the African Union."

            
            
            
            
             
        }
        else if segue.identifier == "tanzaniaSegue"
        {
            sampleString = "Tanzania"
            Q[0][2].QQ = "Which is the largest lake in Tanzania by area."
            Q[0][2].ACs = ["Lake Victoria", "Lake Huron", "Lake Tanganyika", "Lake Manyara"]
            Q[0][2].correctAnswer = "Lake Victoria"
            Q[0][2].AnswerExplination = "Lake Victoria is by far the largest lake in Tanzania. In fact, it is the largest lake in Africa by area! The lake borders Kenya, Tanzania, and Uganda and is home to diverse aquatic wildlife."
            
            Q[1][3].QQ = "Around what percent of Zanzibar's population is Muslim?"
            Q[1][3].ACs = ["61%", "33%", "76%", "99%"]
            Q[1][3].correctAnswer = "99%"
            Q[1][3].AnswerExplination = "Over 99% of Zanzibar's population is Muslim. While people argue over the causes of this sharp disparity, some say it can be atributied to Zanzibar's close historical ties with Oman and Muslim traders."
            
            Q[2][3].QQ = "What is the national animal of Tanzania"
            Q[2][3].ACs = ["Southeast Africa Cheetah", "Grey Crowned Crane", "Masai Giraffes", "Vervet Monkeys"]
            Q[2][3].correctAnswer = "Masai Giraffes"
            Q[2][3].AnswerExplination = "Masai Giraffes are the national animal of Tanzania. It is the tallest giraffe in teh world. The endangered species can be found all throughout Tanzania."
            
            Q[3][3].QQ = "What is the main language used in primary education and parliamentary debate in Tanzania?"
            Q[3][3].ACs = ["Swahili", "English", "Arabic", "Hindi"]
            Q[3][3].correctAnswer = "Swahili"
            Q[3][3].AnswerExplination = "Swahili is the native language of the Swahili people and the offical language of Tanzania. Swahili is simillar to English. Arabic is also widly spoken in Tanzania."
            
            Q[4][0].QQ = "Which is the tallest mountain on the African continent?"
            Q[4][0].ACs = ["Mount Kilimanjaro", "Mount Everest", "Mount Vinson", "Mount Denali"]
            Q[4][0].correctAnswer = "Mount Kilimanjaro"
            Q[4][0].AnswerExplination = "Mount Kilimanjaro is located in Tanzania. Being on of the Seven Summits, Kilimanjaro is the tallest mountain on the continent. You can climb at all times of the year. "
            
            
            
        }
        else if segue.identifier == "nigeriaSegue"
        {
            Q[0][3].QQ = "How many countries does Nigeria border"
            Q[0][3].ACs = ["4", "5", "7", "3"]
            Q[0][3].correctAnswer = "4"
            Q[0][3].AnswerExplination = "Nigeria borders Benin, Cameroon, Chad, and Niger. Nigeria also has a coastline."
            
            Q[1][2].QQ = "Which religon is most commonly practiced in Nigeria"
            Q[1][2].ACs = ["Christianity", "Hinduism", "Racism", "Islam"]
            Q[1][2].correctAnswer = "Islam"
            Q[1][2].AnswerExplination = "Islam is the most practiced religion in Tanzania 54% of Nigerians are Muslims! Christianity is a close second."
            
            Q[2][4].QQ = "The ____ ____ is also know as the Nigerian monkey"
            Q[2][4].ACs = ["Sclater's Guenon", "Bonnet Macaque", "Barbary Macaques", "Ishaan Sinha"]
            Q[2][4].correctAnswer = "Sclater's Guenon"
            Q[2][4].AnswerExplination = "The Sclater's Guenon was thought to be near extinction in the 1980s. This endagnered monkey is found almost exclusivly in Nigeria. Locals consider the Sclater's Guenon sacred."
            
            Q[3][4].QQ = "Which of these aritists is Nigerian"
            Q[3][4].ACs = ["Wizkid", "Louis Armstrong", "Kodak Black", "50 Cent"]
            Q[3][4].correctAnswer = "Wizkid"
            Q[3][4].AnswerExplination = "Wizkid is an influential Nigerian musician. He is one of the biggest African stars of all-time. He has colabed with other major artists such as Drake to reach an international audience."
            
            Q[4][1].QQ = "What is the population of Nigeria?"
            Q[4][1].ACs = ["210 million", "56 million", "172 million", "331 million"]
            Q[4][1].correctAnswer = "210 million"
            Q[4][1].AnswerExplination = "Nigeria has a population of about 210 million people, making it the seventh most populus country on the planet and the most populas county of Africa!"
        }
        
        if let destination = segue.destination as? topicViewController
        {
            
            destination.sampleString = sampleString
            destination.Q = Q
            destination.score = score
            
            
        }
    }
    
    //

}

