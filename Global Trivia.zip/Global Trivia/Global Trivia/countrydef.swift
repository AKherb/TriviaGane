//
//  countrydef.swift
//  Global Trivia
//
//  Created by Aryan Kashyap on 1/26/23.
//

import Foundation

struct Country: Codable{
    var contryName : String
    var Q : [[Question]]
}

struct Question: Codable{
    var QQ : String
    var ACs : [String]
    var correctAnswer : String
    var AnswerExplination : String
    var pointEnabled : Bool
}



