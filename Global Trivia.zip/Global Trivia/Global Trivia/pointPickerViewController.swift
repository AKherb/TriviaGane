//
//  pointPickerViewController.swift
//  Global Trivia
//
//  Created by Aryan Kashyap on 1/29/23.
//

import Foundation
import UIKit

class pointPickerViewController : UIViewController {
    
    @IBOutlet var scoreLabel : UILabel!
    @IBOutlet var onehund : UIButton!
    @IBOutlet var twohund : UIButton!
    @IBOutlet var threehund : UIButton!
    @IBOutlet var fourhund : UIButton!
    @IBOutlet var fivehund : UIButton!
    
    var topicChosen : Int!
    var Q : [[Question]]!
    var pointChosen : Int!
    var score : Int!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if(Q[topicChosen][0].pointEnabled == false)
        {
            onehund.isEnabled = false;
        }
        if(Q[topicChosen][1].pointEnabled == false)
        {
            twohund.isEnabled = false;
        }
        if(Q[topicChosen][2].pointEnabled == false)
        {
            threehund.isEnabled = false;
        }
        if(Q[topicChosen][3].pointEnabled == false)
        {
            fourhund.isEnabled = false;
        }
        if(Q[topicChosen][4].pointEnabled == false)
        {
            fivehund.isEnabled = false;
        }
        
        scoreLabel.text = "Your Score: \(score as Int)";
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "oneSegue"
        {
            pointChosen = 0;
        }
        else if segue.identifier == "twoSegue"
        {
            pointChosen = 1;
        }
        else if segue.identifier == "threeSegue"
        {
            pointChosen = 2;
        }
        else if segue.identifier == "fourSegue"
        {
            pointChosen = 3;
        }
        else if segue.identifier == "fiveSegue"
        {
            pointChosen = 4;
        }
        
        if let destination = segue.destination as? questionAskViewController
        {
            destination.Q = Q
            destination.pointChosen = pointChosen
            destination.score = score
            destination.topicChosen = topicChosen
        }
    }
}
