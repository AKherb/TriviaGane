//
//  questionAskViewController.swift
//  Global Trivia
//
//  Created by Aryan Kashyap on 1/29/23.
//

import Foundation
import UIKit

class questionAskViewController : UIViewController {
    
    var Q : [[Question]] = [[]]
    var pointChosen : Int!;
    var correct : Bool = false;
    var ae : String = "";
    var score : Int!;
    var topicChosen : Int!;
    
    @IBOutlet var questionText : UITextView?
    @IBOutlet var AC1 : UIButton?
    @IBOutlet var AC2 : UIButton?
    @IBOutlet var AC3 : UIButton?
    @IBOutlet var AC4 : UIButton?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        print("rightbeforeError")
        questionText?.text = Q[topicChosen][pointChosen].QQ
        AC1?.setTitle(Q[topicChosen][pointChosen].ACs[0], for: .normal)
        AC2?.setTitle(Q[topicChosen][pointChosen].ACs[1], for: .normal)
        AC3?.setTitle(Q[topicChosen][pointChosen].ACs[2], for: .normal)
        AC4?.setTitle(Q[topicChosen][pointChosen].ACs[3], for: .normal)
        
        Q[topicChosen][pointChosen].pointEnabled = false;
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        ae = Q[topicChosen][pointChosen].AnswerExplination
        if segue.identifier == "oneSegue"
        {
            if Q[topicChosen][pointChosen].ACs[0] == Q[topicChosen][pointChosen].correctAnswer
            {
                correct = true;
                score += (pointChosen+1)*100
            }
        }
        else if segue.identifier == "twoSegue"
        {
            if Q[topicChosen][pointChosen].ACs[1] == Q[topicChosen][pointChosen].correctAnswer
            {
                correct = true;
                score += (pointChosen+1)*100
            }
        }
        else if segue.identifier == "threeSegue"
        {
            if Q[topicChosen][pointChosen].ACs[2] == Q[topicChosen][pointChosen].correctAnswer
            {
                correct = true;
                score += (pointChosen+1)*100
            }
        }
        else if segue.identifier == "fourSegue"
        {
            if Q[topicChosen][pointChosen].ACs[3] == Q[topicChosen][pointChosen].correctAnswer
            {
                correct = true;
                score += (pointChosen+1)*100
            }
        }
        if let destination = segue.destination as? correctORwrongViewController
        {
            destination.correct = correct
            destination.ae = ae;
            destination.score = score;
            destination.Q = Q;
            
        }
    }
    
    
}
