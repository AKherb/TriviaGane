//
//  topicViewController.swift
//  Global Trivia
//
//  Created by Aryan Kashyap on 1/26/23.
//

import Foundation
import UIKit

class topicViewController: UIViewController {

    @IBOutlet var scoreLabel: UILabel!
    
    @IBOutlet var b1 : UIButton!
    @IBOutlet var b2 : UIButton!
    @IBOutlet var b3 : UIButton!
    @IBOutlet var b4 : UIButton!
    @IBOutlet var b5 : UIButton!
    
    var sampleString: String!
    var topicChosen : Int!
    var score : Int!
    var Q : [[Question]]!
    
    var gameOver : Bool = true
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        scoreLabel.text = "Your Score: \(score as Int)";
        print("That is 00 value at topic view controller")
        print(Q[0][0].QQ)
        
        if !Q[0][0].pointEnabled && !Q[0][1].pointEnabled && !Q[0][2].pointEnabled && !Q[0][3].pointEnabled && !Q[0][4].pointEnabled {
            
            b1.isEnabled = false
        }
        if !Q[1][0].pointEnabled && !Q[1][1].pointEnabled && !Q[1][2].pointEnabled && !Q[1][3].pointEnabled && !Q[1][4].pointEnabled {
            
            b2.isEnabled = false
        }
        if !Q[2][0].pointEnabled && !Q[2][1].pointEnabled && !Q[2][2].pointEnabled && !Q[2][3].pointEnabled && !Q[2][4].pointEnabled {
            
            b3.isEnabled = false
        }
        if !Q[3][0].pointEnabled && !Q[3][1].pointEnabled && !Q[3][2].pointEnabled && !Q[3][3].pointEnabled && !Q[3][4].pointEnabled {
            
            b4.isEnabled = false
        }
        if !Q[4][0].pointEnabled && !Q[4][1].pointEnabled && !Q[4][2].pointEnabled && !Q[4][3].pointEnabled && !Q[4][4].pointEnabled {
            
            b5.isEnabled = false
        }
        
        
        
        
        
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        
        if segue.identifier == "geographySegue"
        {
            topicChosen = 0;
        }
        else if segue.identifier == "grpSegue"
        {
            topicChosen = 1;
        }
        else if segue.identifier == "wildlifeSegue"
        {
            topicChosen = 2;
        }
        else if segue.identifier == "mlcSegue"
        {
            topicChosen = 3;
        }
        else if segue.identifier == "randomSegue"
        {
            topicChosen = 4;
        }
        
        if segue.identifier == "gameOver"
        {
            if let destination = segue.destination as? GameOverViewController
            {
                
                destination.score = score;
            }
        }
        else if let destination = segue.destination as? pointPickerViewController
        {
            destination.topicChosen = topicChosen
            print(Q[0][0].QQ)
            destination.Q = Q
            destination.score = score;
        }
        
        
    }
    
    
    

}

