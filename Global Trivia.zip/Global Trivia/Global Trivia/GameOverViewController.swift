//
//  GameOverViewController.swift
//  Global Trivia
//
//  Created by Aryan Kashyap on 1/31/23.
//

import Foundation
import UIKit

class GameOverViewController : UIViewController {
    
    @IBOutlet var scoreLabel : UILabel!
    var score : Int = 0;
    
    override func viewDidLoad() {
        scoreLabel.text = "Final Score : \(score as Int)"
    }
    
}
