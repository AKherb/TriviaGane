//
//  correctORwrongViewController.swift
//  Global Trivia
//
//  Created by Aryan Kashyap on 1/29/23.
//

import Foundation
import UIKit


class correctORwrongViewController: UIViewController {
    
    @IBOutlet var CR : UILabel!
    @IBOutlet var EX : UITextView!
    
    var correct : Bool!
    var ae : String!
    var score : Int!
    
        
    var Q : [[Question]] = [[]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print((score as Int));
        
        
        if(correct)
        {
            CR.text = "CORRECT"
        }
        else
        {
            CR.text = "WRONG"
        }
        
        EX.text = ae
        
        
        
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let destination = segue.destination as? topicViewController
        {
            destination.Q = Q;
            destination.score = score;
        }
    }
    
    
}
